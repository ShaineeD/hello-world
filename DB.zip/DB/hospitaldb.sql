-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 13, 2020 at 09:13 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospitaldb`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `aID` int(11) NOT NULL,
  `appointmentNo` int(11) NOT NULL,
  `sessionDate` date NOT NULL,
  `sessionTime` time NOT NULL,
  `status` tinyint(4) NOT NULL,
  `paymentStatus` tinyint(4) NOT NULL,
  `patientID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `card`
--

CREATE TABLE `card` (
  `cardNo` char(16) NOT NULL,
  `paymentNo` int(11) NOT NULL,
  `cardHolderName` varchar(50) NOT NULL,
  `expiryDate` date NOT NULL,
  `cvv` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `docschedule`
--

CREATE TABLE `docschedule` (
  `ID` int(11) NOT NULL,
  `scheduleID` int(11) NOT NULL,
  `HospitalName` varchar(70) NOT NULL,
  `DoctorName` varchar(70) NOT NULL,
  `Speciality` varchar(70) NOT NULL,
  `Date` varchar(10) NOT NULL,
  `StartTime` varchar(8) NOT NULL,
  `EndTime` varchar(8) NOT NULL,
  `RoomNumber` int(5) NOT NULL,
  `Status` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `docschedule`
--

INSERT INTO `docschedule` (`ID`, `scheduleID`, `HospitalName`, `DoctorName`, `Speciality`, `Date`, `StartTime`, `EndTime`, `RoomNumber`, `Status`) VALUES
(1, 3, 'asd', 'asd', 'asd', '44', '123', '321', 676, 'Yes'),
(2, 4, 'eee', 'eee', 'arrr', '4343', '55', '43', 1, 'no');

-- --------------------------------------------------------

--
-- Table structure for table `doctorconfirmation`
--

CREATE TABLE `doctorconfirmation` (
  `ID` int(11) NOT NULL,
  `scheduleID` int(11) NOT NULL,
  `HospitalName` varchar(70) NOT NULL,
  `DoctorName` varchar(70) NOT NULL,
  `Speciality` varchar(70) NOT NULL,
  `Date` varchar(10) NOT NULL,
  `StartTime` varchar(8) NOT NULL,
  `EndTime` varchar(8) NOT NULL,
  `RoomNumber` int(5) NOT NULL,
  `Status` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctorconfirmation`
--

INSERT INTO `doctorconfirmation` (`ID`, `scheduleID`, `HospitalName`, `DoctorName`, `Speciality`, `Date`, `StartTime`, `EndTime`, `RoomNumber`, `Status`) VALUES
(2, 2, 'ad', 'nmfl', 'ajaj', '2002', '12.30', '6.30', 111, 'no'),
(8, 44, 'addas', 'asd', 'adasd', '33', '44', '55', 133, 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `doctorhospital`
--

CREATE TABLE `doctorhospital` (
  `ID` int(11) NOT NULL,
  `hospitalID` int(11) NOT NULL,
  `docID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `hospital`
--

CREATE TABLE `hospital` (
  `hospitalID` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `description` varchar(200) NOT NULL,
  `phoneNo` varchar(12) NOT NULL,
  `email` varchar(100) NOT NULL,
  `code` varchar(10) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `hospitalFee` double(8,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `pID` int(11) NOT NULL,
  `pFname` varchar(50) NOT NULL,
  `pLname` varchar(50) NOT NULL,
  `pAge` int(11) NOT NULL,
  `pGender` varchar(12) NOT NULL,
  `pAddress` varchar(45) NOT NULL,
  `pContactNo` varchar(15) NOT NULL,
  `pNIC` varchar(12) NOT NULL,
  `pEmail` varchar(50) NOT NULL,
  `pUsername` varchar(50) NOT NULL,
  `pPassword` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `paymentNo` int(11) NOT NULL,
  `amount` float NOT NULL,
  `paymentType` varchar(20) NOT NULL,
  `activeStatus` char(1) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `registereddoctors`
--

CREATE TABLE `registereddoctors` (
  `docID` int(11) NOT NULL,
  `hospitalID` int(11) NOT NULL,
  `docName` varchar(50) DEFAULT NULL,
  `docEmail` varchar(30) DEFAULT NULL,
  `docAddress` varchar(100) DEFAULT NULL,
  `specialization` varchar(50) DEFAULT NULL,
  `workingTime` time DEFAULT NULL,
  `workingDays` varchar(100) DEFAULT NULL,
  `workingHospitals` varchar(100) DEFAULT NULL,
  `docFee` float DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `ID` int(11) NOT NULL,
  `scheduleID` int(6) NOT NULL,
  `HospitalID` varchar(5) NOT NULL,
  `HospitalName` varchar(70) NOT NULL,
  `DoctorID` varchar(5) NOT NULL,
  `DoctorName` varchar(70) NOT NULL,
  `Speciality` varchar(70) NOT NULL,
  `Date` varchar(10) NOT NULL,
  `StartTime` varchar(8) NOT NULL,
  `EndTime` varchar(8) NOT NULL,
  `RoomNumber` int(5) NOT NULL,
  `Status` char(3) NOT NULL DEFAULT 'NO'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`ID`, `scheduleID`, `HospitalID`, `HospitalName`, `DoctorID`, `DoctorName`, `Speciality`, `Date`, `StartTime`, `EndTime`, `RoomNumber`, `Status`) VALUES
(3, 2, 'ASH10', 'ASIRI', 'ASP11', 'Nimal', 'Neuro', '2020/03/04', '6:50:am', '8.50:am', 12, 'N'),
(4, 3, 'DDH99', 'Durdans Hospital', 'MNS15', 'Mr.Isuru Udana', 'Dermatologists', '2020/02/01', '09:30:am', '11:30:am', 200, 'N'),
(6, 4, 'DHH99', 'Durdans Hospital', 'MNN15', 'Mr.Isuru Udana', 'Dermatologists', '2020/02/01', '09:30:am', '11:30:am', 150, 'N'),
(7, 5, 'GEN11', 'Genaral', 'KUS22', 'Mrs.Kushani Gamage', 'ENT sergent', '2020/03/22', '22:30', '01:30', 233, 'N'),
(8, 77, 'sds', 'sss', 'ss', 'ss', '', '0987', '9898', '77', 3, 'yes'),
(11, 6, 'da', 'asd', 'asd', 'aasd', 'asd', '2020-04-22', '01:59', '15:01', 34, 'N'),
(13, 7, 'dca', 'dvs', 'vsd', 'sfv', 'vsd', '2020-04-21', '01:28', '04:00', 45, 'YES');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`aID`),
  ADD KEY `patientID` (`patientID`);

--
-- Indexes for table `card`
--
ALTER TABLE `card`
  ADD PRIMARY KEY (`cardNo`),
  ADD KEY `paymentNo` (`paymentNo`);

--
-- Indexes for table `docschedule`
--
ALTER TABLE `docschedule`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `scheduleID` (`scheduleID`);

--
-- Indexes for table `doctorconfirmation`
--
ALTER TABLE `doctorconfirmation`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `scheduleID` (`scheduleID`);

--
-- Indexes for table `doctorhospital`
--
ALTER TABLE `doctorhospital`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `hospitalID` (`hospitalID`),
  ADD UNIQUE KEY `docID` (`docID`);

--
-- Indexes for table `hospital`
--
ALTER TABLE `hospital`
  ADD PRIMARY KEY (`hospitalID`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`pID`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`paymentNo`);

--
-- Indexes for table `registereddoctors`
--
ALTER TABLE `registereddoctors`
  ADD PRIMARY KEY (`docID`),
  ADD KEY `hospitalID` (`hospitalID`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `scheduleID` (`scheduleID`),
  ADD UNIQUE KEY `HospitalID` (`HospitalID`),
  ADD UNIQUE KEY `DoctorID` (`DoctorID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `aID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `docschedule`
--
ALTER TABLE `docschedule`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `doctorconfirmation`
--
ALTER TABLE `doctorconfirmation`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `doctorhospital`
--
ALTER TABLE `doctorhospital`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hospital`
--
ALTER TABLE `hospital`
  MODIFY `hospitalID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `pID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `paymentNo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `registereddoctors`
--
ALTER TABLE `registereddoctors`
  MODIFY `docID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointment`
--
ALTER TABLE `appointment`
  ADD CONSTRAINT `appointment_ibfk_1` FOREIGN KEY (`patientID`) REFERENCES `patient` (`pID`);

--
-- Constraints for table `card`
--
ALTER TABLE `card`
  ADD CONSTRAINT `card_ibfk_1` FOREIGN KEY (`paymentNo`) REFERENCES `payment` (`paymentNo`);

--
-- Constraints for table `docschedule`
--
ALTER TABLE `docschedule`
  ADD CONSTRAINT `docschedule_ibfk_1` FOREIGN KEY (`scheduleID`) REFERENCES `schedule` (`ID`);

--
-- Constraints for table `doctorhospital`
--
ALTER TABLE `doctorhospital`
  ADD CONSTRAINT `doctorhospital_ibfk_1` FOREIGN KEY (`docID`) REFERENCES `registereddoctors` (`docID`),
  ADD CONSTRAINT `doctorhospital_ibfk_2` FOREIGN KEY (`hospitalID`) REFERENCES `hospital` (`hospitalID`);

--
-- Constraints for table `registereddoctors`
--
ALTER TABLE `registereddoctors`
  ADD CONSTRAINT `registereddoctors_ibfk_1` FOREIGN KEY (`hospitalID`) REFERENCES `hospital` (`hospitalID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
